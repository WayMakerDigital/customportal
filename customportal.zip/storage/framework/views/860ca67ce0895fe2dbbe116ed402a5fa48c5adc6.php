<?php echo $__env->make('dashboard.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <span class="heading">Main</span>
          <ul class="list-unstyled">
            <li class="active"> <a href="/dashboard/<?php echo e($result['id']); ?>"><i class="icon-home"></i>Dashboard</a></li>
            <li><a href="#dashvariants" aria-expanded="false" data-toggle="collapse"> <i class="icon-interface-windows"></i>Account Settings</a>
              <ul id="dashvariants" class="collapse list-unstyled">
                <li><a href="/dashboard/<?php echo e($result['id']); ?>/details">Records</a></li>
                <li><a href="#">Shipping</a></li>
                <li><a href="#">Billing</a></li>
                <li><a href="/dashboard/<?php echo e($result['id']); ?>/courses">Courses</a></li>
              </ul>
            </li>
        </nav>
         <div class="content-inner">
          <!-- Page Header-->
          <header class="page-header">
            <div class="container-fluid">
              <h2 class="no-margin-bottom">Personal Details</h2>
            </div>
          </header>
          <ul class="breadcrumb">
            <div class="container-fluid">
            </div>
          </ul>
          <section class="forms"> 
            <div class="container-fluid">
              <div class="row">
               <div class="col-lg-12">
                  <div class="card">
                    <div class="card-close">
                     </div>
                    <div class="card-header d-flex align-items-center">
                      <h3 class="h4">Details</h3>
                    </div>
                    <div class="card-body">
                      <form class="form-horizontal" action="/dashboard/<?php echo e($result['id']); ?>/details" method="post">
                       <?php echo e(csrf_field()); ?>

                       <?php echo e(method_field('PUT')); ?>


                     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="alert alert-danger"><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                   <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                   <?php endif; ?>
                        <div class="form-group row">
                          <label class="col-sm-3 form-control-label">First Name</label>
                          <div class="col-sm-9">
                         <input type="text" name="firstname" value="<?php echo e($result['first_name']); ?>" class="form-control">
                          </div>
                        </div>
                        <div class="line"></div>
                        <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Last Name</label>
                          <div class="col-sm-9">
                            <input type="text" name="lastname" value="<?php echo e($result['last_name']); ?>" class="form-control">
                          </div>
                        </div>
                        <div class="line"></div>
                        <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Username</label>
                          <div class="col-sm-9">
                            <input type="text" name="username" value="<?php echo e($result['username']); ?>" name="password" class="form-control">
                          </div>
                        </div>
                        <div class="line"></div>
                        <div class="form-group row">
                          <label class="col-sm-3 form-control-label">Email</label>
                          <div class="col-sm-9">
                            <input type="text" name="email" value="<?php echo e($result['email']); ?>" name="password" class="form-control">
                          </div>
                        </div>
                        <div class="form-group row">
                          <div class="col-sm-4 offset-sm-3">
                            <button type="submit" class="btn btn-primary">Save changes</button>
                          </div>
                        </div>
                        </form>
                        </div>
                        </div>
                        </div>
                        </div>
                        </div>
                        </section>
                        </div>
                        </ul>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>